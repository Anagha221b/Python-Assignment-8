#importing library for plotting the graph.
import matplotlib.pyplot as plt
#this is used for formatting to non-exponential.
from matplotlib import ticker

CityA = [500000, 550000, 600000, 650000, 700000, 750000, 800000]
CityB = [800000, 850000, 900000, 950000, 1000000, 1050000, 1100000]
CityC = [1000000, 1050000, 1100000, 1150000, 1200000, 1250000, 1300000]
CityD = [1200000, 1250000, 1300000, 1350000, 1400000, 1450000, 1500000]
years= [2010,2011,2012,2013,2014,2015,2016]

#Plotting the graph for different cities.
plt.plot(years,CityA)
plt.plot(years,CityB)
plt.plot(years,CityC)
plt.plot(years,CityD)

#labelling the x and y axis as per the question
plt.title("Population based on Cities")
plt.xlabel("Years")
plt.ylabel("Population")

#formatting the exponential number for clear visualization in y axis
formatter = ticker.ScalarFormatter()
formatter.set_scientific(False)
plt.gca().yaxis.set_major_formatter(formatter)
plt.show()