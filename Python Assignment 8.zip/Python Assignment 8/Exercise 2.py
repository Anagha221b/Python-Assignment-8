#importing seaborn library for scatterplot
import seaborn as sns
import matplotlib.pyplot as plt

Hours_Studied = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
Test_Scores = [93, 57, 61, 54, 51, 53, 87, 81, 83, 85]

#creating scatter plot
sns.scatterplot(x=Hours_Studied, y=Test_Scores)

#labelling the axis
plt.title("Students Score Analysis")
plt.show()