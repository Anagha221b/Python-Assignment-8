#importing library for plotting the bar chart.
import matplotlib.pyplot as plt

Month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", 
         "Sep", "Oct", "Nov", "Dec"]
Sales = [11860, 10480, 4997, 5523, 13965, 6011, 13158, 9533, 5158, 
         9058, 11346, 6675]

#creating the bar chart
plt.bar(Month, Sales, color = "red")

#labelling the axis
plt.xlabel("Months")
plt.ylabel("Sales")
plt.title("Total sales each month")
plt.show()